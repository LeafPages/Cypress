import CreateLeadPage from "./CreateLeadPage";

class MyLeadsPage{

    /* Click Create Lead Link on Left Menu */
    clickCreateLeadLink(){
        cy.contains('Create Lead').click();
        return new CreateLeadPage();
    }

}

export default MyLeadsPage;