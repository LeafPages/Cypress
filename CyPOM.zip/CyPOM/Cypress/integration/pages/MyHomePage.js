import MyLeadsPage from "./MyLeadsPage";

class MyHomePage{

    /* Click Leads Tab */
    clickLeadsTab(){
        cy.contains('Leads').click();
        return new MyLeadsPage();
    }

  
}

export default MyHomePage;