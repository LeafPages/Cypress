import LoginPage from './../pages/LoginPage'

beforeEach('Login', ()=>{
    cy.visit("http://leaftaps.com/opentaps/");
    new LoginPage()
        .doLogin('DemoSalesManager', 'crmsfa')
        .clickCRMSFA();
})


afterEach('lLogout', ()=>{
   
})

