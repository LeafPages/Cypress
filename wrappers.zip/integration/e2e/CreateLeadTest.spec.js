import LoginPage from '../pages/LoginPage';
import MyHomePage from '../pages/MyHomePage';

const dataset = require('../../fixtures/ui/createLead.json');
require('./../hooks/BaseHooks');

describe('Create Lead Test', ()=> {

    dataset.forEach(eachData => {
        it('Create Lead Positive Test', ()=> {
            new MyHomePage()
                .clickLeadsTab()
                .clickCreateLeadLink()
                .typeCompanyname(eachData.org)
                .typeFirstname(eachData.fname)
                .typeLastname(eachData.lname)
                .clickCreateLeadButton()
                .verifyCompanyName(eachData.org);
            })
    })


})