
class ViewLeadPage{

    /* Click Create Lead Link on Left Menu */
    verifyCompanyName(company){
       cy.get('#viewLead_companyName_sp').invoke('text').then($txt => {
           if($txt.includes(company)){
               cy.log("matches the company name")
           }
       })
    }

}

export default ViewLeadPage;